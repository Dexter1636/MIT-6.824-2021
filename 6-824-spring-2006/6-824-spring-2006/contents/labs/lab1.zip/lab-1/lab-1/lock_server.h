#ifndef lock_server_h
#define lock_server_h

#include "list.h"
#include "ihash.h"

class LS {
public:
  LS();
  void attach(ptr<axprt> sx);

private:
  ptr<asrv> sxx;
  ptr<aclnt> c;


  static void dispatch(LS *, svccb *);
  void acquire(svccb *sbp);
  void release(svccb *sbp);
  void grant_done(str name, bool *r, struct sockaddr_in *, clnt_stat err);
  void send_grant(str name, struct sockaddr_in sin);
  str hex(str s);
};

#endif
