/*
 * server1.C: start up lock_server.C.
 */

#include "amisc.h"
#include "async.h"
#include "arpc.h"
#include "lock_server.h"

void
usage()
{
  fprintf(stderr, "Usage: server1 port\n");
  exit(1);
}

void
done (LS *ls)
{
  delete ls;
  exit (1);
}

int
main(int argc, char *argv[])
{
  int port;

  if(argc == 2 && isdigit(argv[1][0])){
    port = atoi(argv[1]);
  } else {
    usage();
  }

  setbuf(stdout, 0);

  int ss = inetsocket(SOCK_DGRAM, port, INADDR_ANY);
  if(ss < 0){
    fprintf(stderr, "server1: inetsocket failed\n");
    exit(1);
  }
  ptr<axprt> sx = axprt_dgram::alloc(ss);

  LS *ls = new LS();
  ls->attach(sx);

  sigcb (SIGINT, wrap (done, ls));

  amain();
}
